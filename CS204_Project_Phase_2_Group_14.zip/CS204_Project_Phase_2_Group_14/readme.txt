# RISC-V Simulator

This is a RISC-V instruction set architecture (ISA) simulator implemented in C++. It simulates the execution of RISC-V instructions by implementing the five-stage pipeline: Fetch, Decode, Execute, Memory, and Write-back.

## Overview

This simulator implements a subset of the RISC-V 32-bit integer instruction set (RV32I). It supports various instruction formats including R-type, I-type, S-type, B-type, U-type, and J-type instructions. The simulator maintains a simulated processor state including registers, memory, and program counter.

## Memory Organization

The simulator uses two memory segments:
- **Program Memory (MEM)**: Stores program instructions and data with addresses from 0x0 to 0x3FFF.
- **Data Memory (MEM2)**: Stores data with addresses from 0x10000000 to 0x10003FFF.

## Supported Instructions

### R-type Instructions
- ADD, SUB, AND, OR, XOR
- SLL, SRL, SRA (Shift operations)
- SLT (Set less than)

### I-type Instructions
- ADDI, ANDI, ORI, XORI
- SLTI (Set less than immediate)
- SLLI, SRLI, SRAI (Shift immediate operations)
- LB, LH, LW, LBU, LHU (Load operations)
- JALR (Jump and link register)

### S-type Instructions
- SB, SH, SW (Store operations)

### B-type Instructions
- BEQ, BNE, BLT, BGE (Branch operations)

### U-type Instructions
- LUI (Load upper immediate)
- AUIPC (Add upper immediate to PC)

### J-type Instructions
- JAL (Jump and link)

## File Formats

### Program Memory File (input.mc)
Contains program instructions in hexadecimal format, one instruction per line.

Example:
```
00200113
00300193
008000EF
0100006F
00310233
00100313
00008067
00A00293
FFFFFFFF
```

The last instruction is FFFFFFFF which serves as a halt command.

### Data Memory File (input_data.mem)
Contains initial values for data memory locations in the format:
```
ADDRESS VALUE
```

Example:
```
10000000 00
10000001 00
10000002 00
```

## Output Files

- **data_out.mem**: Memory dump after program execution
- **register_file.txt**: Register file contents after program execution

## Usage

1. Compile the simulator:
   ```
   g++ -o riscv_sim main.cpp
   ```

2. Prepare input files:
   - Create an instruction file (input.mc)
   - Create a data memory file (input_data.mem) if needed

3. Run the simulator:
   ```
   ./riscv_sim
   ```

4. Examine output files for results:
   - data_out.mem
   - register_file.txt

## Implementation Details

### Register File
- 32 general-purpose registers (x0 to x31)
- x0 is hardwired to zero and writes to it are ignored

### Simulation Flow

The simulator implements a cycle-accurate simulation of the RISC-V pipeline execution:

```
reset_proc()
load_program_memory("input.mc")
load_data_memory("input_data.mem")
run_RISCVsim() -> cycles through fetch-decode-execute-memory-writeback
write_data_memory()
write_register_file()
```

