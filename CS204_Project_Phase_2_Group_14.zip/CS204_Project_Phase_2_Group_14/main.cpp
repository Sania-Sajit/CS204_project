#include <bits/stdc++.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cstdint>

using namespace std;
// Register file
static unsigned int R[32];
// flags
static int N, C, V, Z;
// memory
static unsigned char MEM[16384]={0};
static unsigned char MEM2[16384]={0}; // Data memory segment
static unsigned int clock_cycles = 0;
// intermediate datapath and control path signals
static unsigned int instruction_word;
static unsigned int opcode;
static unsigned int funct3;
static unsigned int funct7;
static unsigned int rs1;
static unsigned int rs2;
static unsigned int rd;
static unsigned int ALU;
static unsigned int PC = 0;
static unsigned int branchPC = 0;
static int immI, immS, immB, immU, immJ;

static int isBranch;
static int memOp;
static int memOp2;
static int ALU_Result;
static int RFWrite;
static int Result_select;
static int branch_target_select;
static int store_load_op;

// Function to extract opcode
unsigned int get_opcode() {
  return instruction_word & 0x7F; // Extract bits [6:0]
}
unsigned int get_funct3() {
  return (instruction_word >> 12) & 0x7; // Extract bits [14:12]
}
unsigned int get_funct7() {
  return (instruction_word >> 25) & 0x7F; // Extract bits [31:25]
}
// Function to extract register fields
unsigned int get_rs1() {
  return (instruction_word >> 15) & 0x1F; // Bits [19:15]
}
unsigned int get_rs2() {
  return (instruction_word >> 20) & 0x1F; // Bits [24:20]
}
unsigned int get_rd() {
  return (instruction_word >> 7) & 0x1F; // Bits [11:7]
}

// Function to extract immediate values
int get_immI() {
  int imm = (instruction_word >> 20) & 0xFFF; // Extract bits [31:20]
  if (imm & 0x800) {   // Check if the 12th bit is 1 (negative)
    imm |= 0xFFFFF000; // Sign-extend to 32 bits
  }
  return imm;
}
int get_immS() {
  int imm = ((instruction_word >> 25) << 5) |
            ((instruction_word >> 7) & 0x1F); // Combine bits [31:25] and [11:7]
  if (imm & 0x800) {   // Check if the 12th bit is 1 (negative)
    imm |= 0xFFFFF000; // Sign-extend to 32 bits
  }
  return imm;
}
int get_immB() {
  int imm;
  if (instruction_word>>31 == 0){
     imm = ((instruction_word >> 31) << 12) |   // bit 12 (sign)
    ((instruction_word >> 7)  & 0x1) << 11 |  // bit 11
    ((instruction_word >> 25) & 0x3F) << 5 |  // bits 10:5
    ((instruction_word >> 8)  & 0xF)  << 1;   // bits 4:1

// Sign extension
if (imm & 0x1000) {
imm |= 0xFFFFE000;
}} else{ 
     imm = ((instruction_word >> 31) << 12) |   // bit 12 (sign)
    ((instruction_word >> 7)  << 11) |   // bit 11
    ((instruction_word >> 25) << 5)  |   // bits 10:5
    ((instruction_word >> 8)  << 1);     // bits 4:1
// Sign extend if needed
if (imm & 0x1000) {  // Check if bit 12 is set (negative)
imm |= 0xFFFFE000; // Sign-extend to 32 bits
}
}
  return imm;
}
int get_immU() {
  return instruction_word & 0xFFFFF000; // Bits [31:12]
}
int get_immJ() {
  int imm;
  if ((instruction_word >> 31) == 0) {
    // Positive offset handling
    imm = ((instruction_word >> 31) << 20) |   // Bit [31]
          ((instruction_word >> 12) & 0xFF) |  // Bits [19:12]
          ((instruction_word >> 20) & 0x1) |   // Bit [20]
          ((instruction_word >> 21) & 0x3FF);  // Bits [30:21]
    imm = imm << 1;
    if (imm & 0x100000) {  // Check if bit 20 is set (would indicate overflow)
      imm |= 0xFFE00000;   // Sign-extend to 32 bits
    }
  } else {
    // Negative offset handling
    imm = ((instruction_word >> 31) << 20) |   // Bit [31] (sign)
          ((instruction_word >> 21) << 1) |    // Bits [30:21] → [20:1]
          ((instruction_word >> 20) << 11) |   // Bit [20] → bit 11
          ((instruction_word >> 12) << 12);    // Bits [19:12] → [19:12]
    
    // Sign extension
    if (imm & 0x100000) {
      imm |= 0xFFE00000;
    }
  }
  return imm;
}


void reset_proc() {
  for (int i = 0; i < 32; i++)
    R[i] = 0; // Reset registers
  for (int i = 0; i < 4000; i++) {
    MEM[i] = 0;  // Reset program memory
    MEM2[i] = 0; // Reset data memory
  }
  N = C = V = Z = 0; // Reset flags
  cout << "Processor reset completed." << endl;
}

// Modified read_word function to handle both memory segments
int read_word(unsigned char *mem, unsigned int address) {
    int value;
    if (address >= 0x10000000) {
        // Access data memory (MEM2)
        unsigned int real_address = address - 0x10000000;
        
        if (real_address >= 16388) {
            cerr << "Error: Memory access out of bounds: " << hex << address << endl;
            return 0;
        }
        memcpy(&value, MEM2 + real_address, sizeof(value));
    } else {
        // Access program memory (MEM)
        if (address >= 16388) {
            cerr << "Error: Memory access out of bounds: " << hex << address << endl;
            return 0;
        }
        memcpy(&value, mem + address, sizeof(value));
    }
    return value;
}

// Modified write_word function to handle both memory segments
void write_word(unsigned char *mem, unsigned int address, unsigned int data) {
    if (address >= 0x10000000) {
        // Access data memory (MEM2)
        unsigned int real_address = address - 0x10000000;
        if (real_address >= 16388) {
            cerr << "Error: Memory access out of bounds: " << hex << address << endl;
            return;
        }
        memcpy(MEM2 + real_address, &data, sizeof(data));
    } else {
        // Access program memory (MEM)
        if (address >= 16388) {
            cerr << "Error: Memory access out of bounds: " << hex << address << endl;
            return;
        }
        memcpy(mem + address, &data, sizeof(data));
    }
}
// Function to write register file contents to a file
void write_register_file(const string &filename = "register_file.txt") {
  ofstream reg_file(filename);
  if (!reg_file) {
      cerr << "Error opening register file for writing: " << filename << endl;
      return;
  }
  

  // Write header
  reg_file << "========== RISC-V REGISTER FILE ==========\n";
  reg_file << "Register | Hexadecimal value | Decimal Value\n";
  reg_file << "-----------------------------------------\n";
  
  // Special register names
  string reg_names[32] = {
      "x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7",
      "x8", "x9", "x10", "x11", "x12", "x13", "x14", "x15",
      "x16", "x17", "x18", "x19", "x20", "x21", "x22", "x23",
      "x24", "x25", "x26", "x27", "x28", "x29", "x30", "x31"
  };

  // Write all register values
  for (int i = 0; i < 32; i++) {
      reg_file << setw(5) << setfill(' ') << left << reg_names[i] << "    | "
      << "0x" << setw(8) << setfill('0') << right << hex << R[i] << " | "

               << setw(12) << setfill(' ') << right << dec << R[i] << "\n";
  }
  
  // Write PC and flags
  reg_file << "\n-------- PROCESSOR STATE --------\n";
  reg_file << "PC: 0x" << setw(8) << setfill('0') << hex << PC << "\n";
  reg_file << "Clock Cycles: " << dec << clock_cycles << "\n";
  
  reg_file.close();
  cout << "Register file written to " << filename << endl;
}
void load_data_memory(const string &file_name) {
  ifstream fp(file_name);
  if (!fp) {
    cerr << "Error opening data memory file: " << file_name << endl;
    exit(1);
  }

  string line;
  while (getline(fp, line)) {
    // Format expected: address value (both in hex)
    line.erase(0, line.find_first_not_of(" \t\n\r\f\v"));
    if (line.empty()) continue;
    
    unsigned int address, value;
    stringstream ss(line);
    ss >> hex >> address >> value;
    
    // Check if address is in data memory range
    if (address >= 0x10000000) {
      // Adjust address to use MEM2 with the offset
      unsigned int adjusted_address = address - 0x10000000;
      
      // Verify the address is within bounds
      if (adjusted_address + 3 < 16388) {  // +3 for word-sized data
        write_word(MEM, address, value);  // Use the write_word function which handles offsets
      } else {
        cerr << "Warning: Data memory address out of bounds: 0x" << hex << address 
             << " (adjusted: 0x" << adjusted_address << "), skipping" << endl;
      }
    } else {
      // Handle program memory if needed
      if (address + 3 < 16388) {
        write_word(MEM, address, value);
      } else {
        cerr << "Warning: Program memory address out of bounds: 0x" << hex << address 
             << ", skipping" << endl;
      }
    }
  }
  
  fp.close();
  cout << "Data memory loaded successfully." << endl;
}

// Function to load program memory from file
void load_program_memory(const string &file_name) {
    ifstream fp(file_name);
    if (!fp) {
        cerr << "Error opening input memory file: " << file_name << endl;
        exit(1);
    }

    unsigned int address = 0; // Start address
    string line;

    while (getline(fp, line)) {
        // Remove any leading/trailing whitespace
        line.erase(0, line.find_first_not_of(" \t\n\r\f\v"));
        line.erase(line.find_last_not_of(" \t\n\r\f\v") + 1);

        // Skip empty lines
        if (line.empty()) {
            continue;
        }

        // Convert the 32-bit hexadecimal string to a 32-bit integer
        unsigned int instruction;
        stringstream ss;
        ss << hex << line;
        ss >> instruction;

        // Write the 32-bit instruction to memory
        write_word(MEM, address, instruction);
        cout << "Loading instruction: 0x" << hex << instruction << " at address: 0x" << address << endl;

        // Increment the address by 4 (since each instruction is 32 bits)
        address += 4;
    }

    if (fp.fail() && !fp.eof()) {
        cerr << "Error reading input memory file: Invalid format" << endl;
        exit(1);
    }

    fp.close();
    cout << "Program memory loaded successfully." << endl;
}

// Function to write data memory to file
void write_data_memory() {
  ofstream fp("data_out.mem");
  if (!fp) {
      cerr << "Error opening data_out.mem file for writing" << endl;
      return;
  }

  // Write program memory (MEM)
  for (unsigned int i = 0; i < 4000; i += 4) {
      // Read word from program memory
      int instruction = 0;
      memcpy(&instruction, MEM + i, sizeof(instruction));
      
      // Format address as 8-digit hex
      fp << setw(8) << setfill('0') << hex << uppercase << i << " ";

      // Format instruction as 8-digit hex with spaces every two hex digits
      fp << setw(2) << setfill('0') << ((instruction >> 24) & 0xFF) << " "
         << setw(2) << setfill('0') << ((instruction >> 16) & 0xFF) << " "
         << setw(2) << setfill('0') << ((instruction >> 8) & 0xFF) << " "
         << setw(2) << setfill('0') << (instruction & 0xFF) << endl;
  }
  fp<<"\n\n\n\n\n\n\n\n---------DATA MEMORY-------------------\n\n\n";

  // Write data memory (MEM2)
  for (unsigned int i = 0; i < 4000; i += 4) {
      // Read word from data memory
      int data = 0;
      memcpy(&data, MEM2 + i, sizeof(data));
      
      // Format address as 8-digit hex (with the 0x10000000 offset)
      fp << setw(8) << setfill('0') << hex << uppercase << (i + 0x10000000) << " ";

      // Format data as 8-digit hex with spaces every two hex digits
      fp << setw(2) << setfill('0') << ((data >> 24) & 0xFF) << " "
         << setw(2) << setfill('0') << ((data >> 16) & 0xFF) << " "
         << setw(2) << setfill('0') << ((data >> 8) & 0xFF) << " "
         << setw(2) << setfill('0') << (data & 0xFF) << endl;
  }

  fp.close();
  cout << "Data memory written to data_out.mem" << endl;
}

// should be called when instruction is swi_exit
void swi_exit() {
  write_data_memory();
  exit(0);
}

// reads from the instruction memory and updates the instruction register
void fetch() {
  
  instruction_word = read_word(MEM, PC);
  cout << "FETCH: Instruction " << hex << instruction_word << " at PC " << hex
       << PC << endl;
       PC += 4; // Increment PC to next instruction
    cout<< "####### End Fetch #########"<<endl;
}
// reads the instruction register, reads operand1, operand2 fromo register file,
// decides the operation to be performed in execute stage
void decode() {
  opcode = get_opcode();
  char format;
  if (opcode == 0b0110011) {
    format = 'R';
  } else if (opcode == 0b0010011 || opcode == 0b0000011 || opcode == 0b1100111 ||
             opcode == 0b1110011) {
    format = 'I';
  } else if (opcode == 0b0100011) {
    format = 'S';
  } else if (opcode == 0b1100011) {
    format = 'B';
  } else if (opcode == 0b1101111) {
    format = 'J';
  } else if (opcode == 0b0010111 || opcode == 0b0110111) {
    format = 'U';
  } else {
    format = 'Z';
  }

  switch (format) {
    case 'R': {
      funct3 = get_funct3();
      funct7 = get_funct7();
      switch (funct3) {
        case 0b000:
          if (funct7 == 0b00000000) {
            ALU = 0;
            cout << "Operation is ADD" << endl;
          }else if (funct7 == 0b00000001) {  // <-- NEW: Multiply extension
            ALU = 25;
            cout << "Operation is MUL" << endl;
          } else {
            ALU = 1;
            cout << "Operation is SUB" << endl;
          }
          break;
        case 0b001:
          ALU = 2;
          cout << "Operation is SLL" << endl;
          break;
        case 0b010:
          ALU = 3;
          cout << "Operation is SLT" << endl;
          break;
        case 0b100:
          ALU = 4;
          cout << "Operation is XOR" << endl;
          break;
        case 0b101:
          if (funct7 == 0b00000000) {
            ALU = 5;
            cout << "Operation is SRL" << endl;
          } else {
            ALU = 6;
            cout << "Operation is SRA" << endl;
          }
          break;
        case 0b110:
          ALU = 7;
          cout << "Operation is OR" << endl;
          break;
        case 0b111:
          ALU = 8;
          cout << "Operation is AND" << endl;
          break;
        default:
          cout << "Invalid funct3" << endl;
        }
      Result_select = 3;
      memOp = 0;
      RFWrite = 1;
      rs1 = R[get_rs1()];
      rs2 = R[get_rs2()];
      cout<< "DECODE: Operands: x" <<dec<<get_rs1()<< " = "<<rs1 << " , x" <<dec<< get_rs2()<<" = "<<rs2 <<endl;
      cout << "Destination register: x" << dec<< get_rd() << endl;

  }
    break;
    case 'I': {
      funct3 = get_funct3();
      int bit4 = (opcode >> 4) & 0x1;
      int bit6 = (opcode >> 6) & 0x1;
      if (bit4==1){
      switch (funct3){
        case 0b000:
          ALU = 9;
          cout << "Operation is ADDI" << endl;
          break;
        case 0b001:
          ALU = 10;
          cout << "Operation is SLLI" << endl;
          break;
        case 0b010:  
          ALU = 11;
          cout << "Operation is SLTI" << endl;
          break;
        case 0b100:
          ALU = 12;
          cout << "Operation is XORI" << endl;
          break;
        case 0b101:
          funct7 = get_funct7();
          if (funct7 == 0b00000000){
          ALU = 13;
          cout << "Operation is SRLI" << endl;
          } else {
            ALU = 14;
            cout << "Operation is SRAI" << endl;
          }
          break;
        case 0b110:
          ALU = 15;
          cout << "Operation is ORI" << endl;
          break;
        case 0b111:
          ALU = 16;
          cout << "Operation is ANDI" << endl;
          break;
    default:
      cout << "Invalid funct3" << endl; 
    } 
        Result_select = 3;
        memOp = 0;
        RFWrite = 1;
    } else if (bit6==0){ //load
        ALU = 0;
        cout << "Operation is Load" << endl;
        store_load_op = funct3;
      Result_select = 2;
      memOp = 2;
      RFWrite = 1;
    } else {
        cout << "Operation is JALR"<<endl;
        ALU = 17;
        Result_select = 0;
        memOp = 0;
        RFWrite = 1;  
    }   
      rs1 = R[get_rs1()];
      immI = (get_immI());
      rs2=immI;
      cout<< "DECODE: Operands: x" <<dec<<get_rs1()<< " = "<<rs1 << " , Immediate operand " <<dec<< immI<<endl;
      cout << "Destination register: x" << dec<< get_rd() << endl;

    }
        break;

    case 'S':{
      funct3 = get_funct3();
      ALU=0;
      store_load_op = funct3;
      memOp = 1;
      RFWrite = 0;

      memOp2 = R[get_rs2()];
      rs1 = R[get_rs1()];
      immS = (get_immS());
      rs2 = immS;
      cout<<"DECODE: Store Instruction"<<endl;
      cout<< " First operand: x" <<dec<<get_rs1()<< " = "<<rs1 << " , Immediate operand = " <<dec<< immS<<endl;
    }
    break;
    case 'B':
      {
        funct3 = get_funct3();
        branch_target_select=0;
        RFWrite= 0;
        memOp=0; 
        rs1=R[get_rs1()];
        rs2=R[get_rs2()];
        immB = (get_immB());
        switch (funct3)
          {
          case 0:
              {
                  ALU=18;
                  cout<<"BEQ";
              }
              break;
          case 1:
              {
                  cout<<"BNE";
                  ALU=19;
              }
              break;
          case 4:
              {
                  cout<<"BLT";
                  ALU=20;

              }
              break;
          case 5:
              {
                  cout<<"BGE";
                  ALU=21;
              }
              break;

          default:
          {
              cerr << "Error: Could not identify instruction.\n";
              break;
          }
              break;
          }
        cout<<"\nFirst Operand X"<<dec<<get_rs1()<<", Second Operand X"<<dec<<get_rs2()<<endl;
        cout<<"DECODE: "<<"Read Register X"<<dec<<get_rs1()<<" = "<<rs1<<", X"<<dec<<get_rs2()<<" = "<<rs2<<", immB = "<<dec<<immB<<endl;

        }
        break;


    case 'J': {
      rd = get_rd();
      immJ = get_immJ();

      memOp = 0; // No memory operation
      branch_target_select = 1; // Use immJ for branch target
      ALU = 24; // Set ALU operation for JAL
      Result_select = 0; // Select ALU result
      RFWrite = 1; // Write to register file

      cout << "DECODE: JAL" << endl;
      cout << "Destination Register X" << dec<<rd << ", immJ = " <<dec<<immJ << endl;
    }
    break;
    case 'U': {
      rd = get_rd();
      immU = get_immU();
      int bit5 = (opcode >> 5) & 0x1;

      if (bit5==1) { // LUI
          cout << "LUI\n";
          ALU = 22; // Set ALU operation for LUI
          Result_select = 1; // Select immediate as result
          memOp = 0; // No memory operation
          RFWrite = 1; // Write to register file
          cout << "DECODE: Destination Register X" <<dec<< rd << endl;
          cout << "immU = " <<dec<< immU << endl;

      } else  { // AUIPC
          cout << "AUIPC\n";
          ALU = 23; // Set ALU operation for AUIPC (ADD)
          Result_select = 1; // Select immediate as result
          memOp = 0; // No memory operation
          RFWrite = 1; // Write to register file

          rs1 = immU; // First operand is immU
          rs2 = PC; // Second operand is PC

          cout << "DECODE: Destination Register X" << dec<<rd << endl;
          cout << "First Operand immU = " << dec<<immU << ", Second Operand PC = " << PC << endl;
      } 

    }
      break;
    default:
      cerr << "Error: Could not identify instruction.\n";
      break;
  }

  cout<< "####### End Decode #########"<<endl;
}
// executes the ALU operation based on ALUop
void execute() {
  isBranch=0;
    switch(ALU){
        // R-type instructions
        case 0:
            ALU_Result = rs1 + rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " + " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 1:
            ALU_Result = rs1 - rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " - " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;  
        case 2: 
            ALU_Result = rs1 << rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " << " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 3:
          ALU_Result = static_cast<int>(rs1) < static_cast<int>(rs2);
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " < " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 4:    
            ALU_Result = rs1 ^ rs2;      
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " ^ " << rs2 << endl;    
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 5:
            ALU_Result = rs1 >> rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " >> " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 6:
            ALU_Result = static_cast<int>(rs1) >> rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " >> " << rs2 << " (arithmetic)" << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 7:  
            ALU_Result = rs1 | rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " | " << rs2 << endl;    
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 8:
            ALU_Result = rs1 & rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " & " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;

        // I-type instructions
        case 9: // ADDI
            ALU_Result = rs1 + immI;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " + " << immI << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 10: // SLLI
            ALU_Result = rs1 << (immI & 0x1F);
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " << " << (immI & 0x1F) << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 11: // SLTI
            ALU_Result = (static_cast<int>(rs1) < static_cast<int>(immI)) ? 1 : 0;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " < " << immI << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 12: // XORI
            ALU_Result = rs1 ^ immI;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " ^ " << immI << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 13: // SRLI
            ALU_Result = rs1 >> (immI & 0x1F);
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " >> " << (immI & 0x1F) << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 14: // SRAI
            ALU_Result = static_cast<int>(rs1) >> (immI & 0x1F);
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " >> " << (immI & 0x1F) << " (arithmetic)" << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 15: // ORI
            ALU_Result = rs1 | immI;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " | " << immI << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 16: // ANDI
            ALU_Result = rs1 & immI;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " & " << immI << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 17: // JALR
          
            branchPC = (rs1 + immI) & ~1; // Clear the least significant bit
            ALU_Result=PC;            
            
            isBranch = 2;
            cout << "EXECUTE: "<< endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            cout << "Branch target: " << branchPC << endl;
            break;

        // B-type instructions
        case 18: // BEQ
            isBranch = (rs1 == rs2) ? 1 : 0;
            cout << "EXECUTE: Comparing " << rs1 << " == " << rs2 << endl;
            cout << "Branch " << (isBranch ? "taken" : "not taken") << endl;
            if (isBranch) {
                branchPC = PC + immB-4;
                cout << "Branch target: " << branchPC << endl;
            }
            break;
        case 19: // BNE
            isBranch = (rs1 != rs2) ? 1 : 0;
            cout << "EXECUTE: Comparing " << rs1 << " != " << rs2 << endl;
            cout << "Branch " << (isBranch ? "taken" : "not taken") << endl;
            if (isBranch) {
                branchPC = PC + immB-4;
                cout << "Branch target: " << branchPC << endl;
            }
            break;
        case 20: // BLT
            isBranch = (static_cast<int>(rs1) < static_cast<int>(rs2)) ? 1 : 0;
            cout << "EXECUTE: Comparing " << rs1 << " < " << rs2 << endl;
            cout << "Branch " << (isBranch ? "taken" : "not taken") << endl;
            if (isBranch) {
              branchPC = PC + immB-4;
                cout << "Branch target: " << branchPC << endl;
            }
            break;
        case 21: // BGE
            isBranch = (static_cast<int>(rs1) >= static_cast<int>(rs2)) ? 1 : 0;
            branchPC = PC + immB-4;
            cout << "EXECUTE: Comparing " << rs1 << " >= " << rs2 << endl;
            cout << "Branch " << (isBranch ? "taken" : "not taken") << endl;
            if (isBranch) {
                cout << "Branch target: " << branchPC << endl;
            }
            break;

        // U-type instructions
        case 22: // LUI
            ALU_Result = immU;
            isBranch = 0;
            cout << "EXECUTE: Loading upper immediate " << immU << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        case 23: // AUIPC
            ALU_Result = PC + immU-4;
            isBranch = 0;
            cout << "EXECUTE: " << PC-4 << " + " << immU << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;

        // J-type instruction
        case 24: // JAL
            ALU_Result = PC ;
            branchPC = (PC-4)+ immJ;
            isBranch = 1;
            cout << "EXECUTE:" << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            cout << "Jump target: " <<hex<< branchPC << endl;
            break;
            case 25: // MUL
            ALU_Result = rs1 * rs2;
            isBranch = 0;
            cout << "EXECUTE: " << rs1 << " * " << rs2 << endl;
            cout << "Result: " << ALU_Result << " in x" << get_rd() << endl;
            break;
        // Load/Store operations
        // For these, the ALU computes the effective address
        // Note: If ALU == 0, this could be either ADD or Load/Store
        // Need to check memOp to disambiguate
        default:
            cout << "Invalid ALU operation" << endl;
    }

    // Handle load instructions
    if (memOp == 2) {
        ALU_Result = rs1 + immI; // Calculate effective address
        isBranch = 0;
        cout << "EXECUTE: Load operation, address = " << rs1 << " + " << immI << " = " << ALU_Result << endl;
    }

    // Handle store instructions
    if (memOp == 1) {
        ALU_Result = rs1 + immS; // Calculate effective address
        isBranch = 0;
        cout << "EXECUTE: Store operation, address = " << rs1 << " + " << immS << " = " << ALU_Result << endl;
    }

    cout << "####### End Execute #########" << endl;
}
// perform the memory operation
void mem() {
  if (memOp == 1) { // Store operation
      cout << "MEMORY: Store operation at address 0x" << hex << ALU_Result << endl;
      unsigned char *target_mem;
      unsigned int adjusted_address;
      
      if (ALU_Result >= 0x10000000) {
          // Data memory access (MEM2)
          target_mem = MEM2;
          adjusted_address = ALU_Result - 0x10000000;
          cout << "Using data memory segment (MEM2)" << endl;
      } else {
          // Program memory access (MEM)
          target_mem = MEM;
          adjusted_address = ALU_Result;
          cout << "Using program memory segment (MEM)" << endl;
      }

      switch (store_load_op) {
          case 0b000: // SB - Store Byte
              target_mem[adjusted_address] = memOp2 & 0xFF;
              cout << "Storing byte: 0x" << hex << (memOp2 & 0xFF) << endl;
              break;
          case 0b001: // SH - Store Halfword
              target_mem[adjusted_address] = memOp2 & 0xFF;
              target_mem[adjusted_address + 1] = (memOp2 >> 8) & 0xFF;
              cout << "Storing halfword: 0x" << hex << (memOp2 & 0xFFFF) << endl;
              break;
          case 0b010: // SW - Store Word
              target_mem[adjusted_address] = memOp2 & 0xFF;
              target_mem[adjusted_address + 1] = (memOp2 >> 8) & 0xFF;
              target_mem[adjusted_address + 2] = (memOp2 >> 16) & 0xFF;
              target_mem[adjusted_address + 3] = (memOp2 >> 24) & 0xFF;
              cout << "Storing word: 0x" << hex << memOp2 << endl;
              break;
          default:
              cout << "Invalid store operation" << endl;
              break;
      }
  } else if (memOp == 2) { // Load operation
      cout << "MEMORY: Load operation from address 0x" << hex << ALU_Result << endl;
      unsigned char *target_mem;
      unsigned int adjusted_address;
      
      if (ALU_Result >= 0x10000000) {
          // Data memory access (MEM2)
          target_mem = MEM2;
          adjusted_address = ALU_Result - 0x10000000;
          cout << "Using data memory segment (MEM2)" << endl;
      } else {
          // Program memory access (MEM)
          target_mem = MEM;
          adjusted_address = ALU_Result;
          cout << "Using program memory segment (MEM)" << endl;
      }

      switch (store_load_op) {
          case 0b000: // LB - Load Byte
              ALU_Result = static_cast<int8_t>(target_mem[adjusted_address]); // Sign-extend
              cout << "Loaded byte (sign-extended): 0x" << hex << ALU_Result << endl;
              break;
          case 0b001: // LH - Load Halfword
              ALU_Result = static_cast<int16_t>(target_mem[adjusted_address] | 
                          (target_mem[adjusted_address + 1] << 8)); // Sign-extend
              cout << "Loaded halfword (sign-extended): 0x" << hex << ALU_Result << endl;
              break;
          case 0b010: // LW - Load Word
              ALU_Result = target_mem[adjusted_address] | 
                          (target_mem[adjusted_address + 1] << 8) |
                          (target_mem[adjusted_address + 2] << 16) |
                          (target_mem[adjusted_address + 3] << 24);
              cout << "Loaded word: 0x" << hex << ALU_Result << endl;
              break;
          case 0b100: // LBU - Load Byte Unsigned
              ALU_Result = target_mem[adjusted_address] & 0xFF; // Zero-extend
              cout << "Loaded byte (zero-extended): 0x" << hex << ALU_Result << endl;
              break;
          case 0b101: // LHU - Load Halfword Unsigned
              ALU_Result = (target_mem[adjusted_address] | 
                          (target_mem[adjusted_address + 1] << 8)) & 0xFFFF; // Zero-extend
              cout << "Loaded halfword (zero-extended): 0x" << hex << ALU_Result << endl;
              break;
          default:
              cout << "Invalid load operation" << endl;
              break;
      }
  } else {
      cout << "MEMORY: No memory operation" << endl;
  }

  // Update PC for branches and jumps
  if (isBranch == 1) {
      cout << "MEMORY: Taking branch to address 0x" << hex << branchPC << endl;
      PC = branchPC;
  } else if (isBranch == 2) { // JALR
      cout << "MEMORY: Taking jump to address 0x" << hex << branchPC << endl;
      PC = branchPC;
  }

  cout << "####### End Memory #########" << endl;
}
// writes the results back to register file
void write_back() {
    if (RFWrite && get_rd() != 0) { // Don't write to x0
        switch (Result_select) {
            case 0: // PC+4 (for JAL/JALR)
                R[get_rd()] = ALU_Result;
                cout << "WRITEBACK: Writing Return Address " << ALU_Result << " to x" << get_rd() << endl;
                break;
            case 1: // Immediate result
                R[get_rd()] = ALU_Result;
                cout << "WRITEBACK: Writing immediate value " << dec << ALU_Result << " to x" << get_rd() << endl;
                break;
            case 2: // Memory load result
                R[get_rd()] = ALU_Result;
                cout << "WRITEBACK: Writing memory loaded value " << dec << ALU_Result << " to x" << get_rd() << endl;
                break;
            case 3: // ALU result
                R[get_rd()] = ALU_Result;
                cout << "WRITEBACK: Writing ALU result " << dec << ALU_Result << " to x" << get_rd() << endl;
                break;
            default:
                cout << "WRITEBACK: Invalid result selection" << endl;
                break;
        }
    } else if (!RFWrite) {
        cout << "WRITEBACK: No register write" << endl;
    } else {
        cout << "WRITEBACK: Attempted write to x0 (ignored)" << endl;
    }

    // Update flags based on the ALU_Result
    Z = (ALU_Result == 0) ? 1 : 0;  // Zero flag
    N = (ALU_Result < 0) ? 1 : 0;   // Negative flag

    cout << "####### End Writeback #########" << endl;
    cout << endl;
}

void run_RISCVsim() {
    while (1) {
        clock_cycles++;
        cout<<"PC before fetch  "<<hex<<PC<<endl;
        fetch();
       if (instruction_word == 0xFFFFFFFF) {
            cout << "Simulation halted." << endl;
            break;
        }
        decode();
        execute();
        mem();
        write_back();
        cout << "Clock cycle " << dec<<clock_cycles << " completed." << endl;
        cout << endl;
    }
}

int main() {
  reset_proc(); // Initialize memory and registers
  load_program_memory("input.mc"); // Load program into memory
  load_data_memory("input_data.mem"); // Load data into data memory segment
  run_RISCVsim(); // Start simulation
  write_data_memory(); // Write both memory segments to output file
  write_register_file();
  return 0;
}