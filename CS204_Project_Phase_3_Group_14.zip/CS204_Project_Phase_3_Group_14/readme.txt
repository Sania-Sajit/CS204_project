# RISC-V Pipelined Processor Simulator

This is an advanced RISC-V instruction set architecture (ISA) simulator implemented in C++. It features a comprehensive five-stage pipeline with hazard detection, data forwarding, and branch prediction capabilities.

## Features

- Full five-stage pipeline implementation (Fetch, Decode, Execute, Memory, Write-back)
- Support for RV32I instruction set
- Pipeline hazard detection and handling
- Data forwarding for improved pipeline performance
- Branch prediction with a Pattern History Table (PHT) and Branch Target Buffer (BTB)
- Memory hierarchy with separate instruction and data segments
- Detailed execution statistics and visualization options
- Configurable execution modes through knob settings

## Memory Organization

The simulator uses three memory segments:
- **Program Memory (MEM)**: Stores instructions (0x0 to 0x3FFF)
- **Data Memory (MEM2)**: Stores global data (0x10000000 to 0x10003FFF)
- **Stack Memory (STACK_MEM)**: Manages function calls and local variables

## Configuration Knobs

The simulator supports various configuration options through knobs:
- **Knob1**: Toggle between pipelined (true) and non-pipelined (false) execution
- **Knob2**: Enable/disable data forwarding
- **Knob3**: Print register file after each cycle
- **Knob4**: Print pipeline registers after each cycle
- **Knob5**: Track a specific instruction by number
- **Knob6**: Enable/disable branch prediction

## Branch Prediction

The simulator implements a 1-bit branch predictor with:
- Pattern History Table (PHT) tracking taken/not-taken predictions
- Branch Target Buffer (BTB) storing predicted branch targets
- History tracking for prediction analysis
- Size-limited tables to prevent memory growth issues

## Input Files

### Program Memory File (input.mc)
Contains RISC-V instructions in hexadecimal format, one per line.

Example:
```
00200113
00300193
008000EF
0100006F
00310233
00100313
00008067
00A00293
FFFFFFFF
```

The last instruction is FFFFFFFF which serves as a halt command.

### Data Memory File (input_data.mem)
Contains initial values for data memory locations in the format:
```
ADDRESS VALUE
```

Example:
```
10000000 00
10000001 00
10000002 00
```

## Output Files

- **data_out.mem**: Memory dump after program execution
- **register_file.txt**: Register file contents after program execution

## Usage

1. Compile the simulator:
   ```
   g++ -o riscv_sim main.cpp
   ```

2. Prepare input files:
   - Create an instruction file (input.mc)
   - Create a data memory file (input_data.mem) if needed

3. Run the simulator:
   ```
   ./riscv_sim
   ```

4. Examine output files for results:
   - data_out.mem
   - register_file.txt

## Implementation Details

### Register File
- 32 general-purpose registers (x0 to x31)
- x0 is hardwired to zero and writes to it are ignored

### Simulation Flow

The simulator implements a cycle-accurate simulation of the RISC-V pipeline execution:

```
reset_proc()
load_program_memory("input.mc")
load_data_memory("input_data.mem")
run_RISCVsim() -> cycles through fetch-decode-execute-memory-writeback
write_data_memory()
write_register_file()
```

