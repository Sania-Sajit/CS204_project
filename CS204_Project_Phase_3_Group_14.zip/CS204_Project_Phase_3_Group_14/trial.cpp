//working for branch rpediction,not for simple pipeline

#include <bits/stdc++.h>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <sstream>
using namespace std;
// Register file
static unsigned int R[32];
bool end_of_program = false; // Flag to indicate end of program

struct IF_ID_Reg {
  unsigned int PC;
  unsigned int instruction;
  bool valid;
};

struct ID_EX_Reg {
  unsigned int PC;
  unsigned int immI;
  unsigned int immJ;
  unsigned int immB;
  unsigned int immU;
  unsigned int immS;
  unsigned int rs1;
  unsigned int rs2;
  unsigned int rs2_reg;
  unsigned int rd;
  unsigned int opcode;
  unsigned int funct3;
  unsigned int funct7;
  bool valid;
  // Control signals
  int ALU_op;
  bool mem_read;
  bool mem_write;
  bool reg_write;
  bool branch;
  bool branch_taken;

  unsigned int branch_target;
  int Result_select; // For ALU result or immediate

};

struct EX_MEM_Reg {
  unsigned int PC;
  unsigned int ALU_result;
  unsigned int rs2_val;
  unsigned int rd; // rd holds the register number, not the value
  bool valid;
  // Control signals
  bool mem_read;
  bool mem_write;
  bool reg_write;
  bool branch_taken; // Added to track branch taken status
  unsigned int branch_target; // Added to track branch target address
  bool branch; // Added to track branch status
};

struct MEM_WB_Reg {
  unsigned int PC;
  unsigned int ALU_result;
  unsigned int mem_data;
  unsigned int rd;
  bool valid;
  // Control signals
  bool reg_write;
  bool mem_read;
};

// flags
static int N, C, V, Z;
// memory
static unsigned char MEM[16384] = {0};
static unsigned char MEM2[16384] = {0};      // Data memory segment
static unsigned char STACK_MEM[16384] = {0}; // 16KB stack memory
// MEMORY CONFIGURATION
static unsigned int STACK_POINTER = 0x7FFFFFDC; // Initial stack pointer value
//static const unsigned int STACK_BASE = 0x7FFFFFDC;
//static const unsigned int STACK_SIZE = 16384;
//static const unsigned int STACK_TOP = STACK_BASE - STACK_SIZE;
static unsigned int clock_cycles = 0;
// intermediate datapath and control path signals

static unsigned int PC = 0;

struct Statistics {
  unsigned int total_cycles;
  unsigned int total_instructions;
  unsigned int data_transfer_inst;
  unsigned int alu_inst;
  unsigned int control_inst;
  unsigned int stalls;
  unsigned int data_hazards;
  unsigned int control_hazards;
  unsigned int branch_mispredictions;
  unsigned int data_stalls;
  unsigned int control_stalls;

  Statistics() {
    total_cycles = 0;
    total_instructions = 0;
    data_transfer_inst = 0;
    alu_inst = 0;
    control_inst = 0;
    stalls = 0;
    data_hazards = 0;
    control_hazards = 0;
    branch_mispredictions = 0;
    data_stalls = 0;
    control_stalls = 0;
  }
};

// Knob settings
struct Knobs {
  bool Knob1;
  bool Knob2;
  bool Knob3;
  bool Knob4;
  int Knob5;
  bool Knob6;

  Knobs() {
    Knob1 = false;
    Knob2 = false;
    Knob3 = false;
    Knob4 = false;
    Knob5 = -1;
    Knob6 = false;
  }
};

IF_ID_Reg IF_ID;
ID_EX_Reg ID_EX;
EX_MEM_Reg EX_MEM;
MEM_WB_Reg MEM_WB;

Statistics stats;
Knobs knobs;

class BranchPredictor {
  public:
      // Use char instead of bool for state
      unordered_map<unsigned int, char> PHT;  // 'T' for taken, 'N' for not taken
      unordered_map<unsigned int, unsigned int> BTB; // Branch Target Buffer
      
      // Track prediction history for analysis
      unordered_map<unsigned int, string> bpob_predicted;
      unordered_map<unsigned int, string> bpob_actual;
      
      // Max entries to prevent unbounded growth
      static const unsigned int MAX_ENTRIES = 64;
      
      // Constructor
      BranchPredictor() {}
      
      // Predict if branch will be taken
      bool predict(unsigned int pc) {
          // Initialize to 'N' (not taken) if first encounter
          if (PHT.find(pc) == PHT.end()) {
              PHT[pc] = 'N';
              bpob_predicted[pc] = "";
              bpob_actual[pc] = "";
              return false;  // Default NOT TAKEN
          }
          
          return (PHT[pc] == 'T');  // Return true if state is 'T'
      }
      
      // Get target address
      unsigned int get_target(unsigned int pc) {
          if (BTB.find(pc) != BTB.end()) {
              return BTB[pc];
          }
          return pc + 4;  // Default to next instruction
      }
      
      // Update predictor with actual outcome
      void update(unsigned int pc, bool taken, unsigned int target) {
          // Limit table size
          if (PHT.size() >= MAX_ENTRIES && PHT.find(pc) == PHT.end()) {
              if (!PHT.empty()) {
                  auto oldest = PHT.begin();
                  PHT.erase(oldest);
                  
                  if (BTB.find(oldest->first) != BTB.end()) {
                      BTB.erase(oldest->first);
                  }
                  
                  if (bpob_predicted.find(oldest->first) != bpob_predicted.end()) {
                      bpob_predicted.erase(oldest->first);
                      bpob_actual.erase(oldest->first);
                  }
              }
          }
          
          // Record current prediction in history
          if (PHT.find(pc) != PHT.end()) {
              bpob_predicted[pc] += PHT[pc];
          }
          
          // Record actual outcome
          bpob_actual[pc] += (taken ? 'T' : 'N');
          
          // Update state based on actual outcome
          PHT[pc] = (taken ? 'T' : 'N');
          
          // Update branch target if taken
          if (taken) {
              BTB[pc] = target;
          }
      }
  };

// Update the HazardDetectionUnit class definition
class HazardDetectionUnit {
private:
    bool stall_flag;
    int stall_cycles;

public:
    HazardDetectionUnit() : stall_flag(false), stall_cycles(0) {}

    bool detect_hazard(unsigned int rs1, unsigned int rs2) {
        // Check for load-use hazard, which requires a stall even with forwarding
        if (knobs.Knob2){
        if (ID_EX.mem_read && ID_EX.rd != 0 && 
            (ID_EX.rd == rs1 || ID_EX.rd == rs2)) {
            // Load-use hazard detected - need to stall for 1 cycle
            stats.data_hazards++;
            stats.stalls += 1;
            stats.data_stalls += 1;
            stall_cycles = 1;
            stall_flag = true;
            cout << "HAZARD: Load-use hazard detected between instruction at 0x" 
                 << hex << ID_EX.PC << " and 0x" << IF_ID.PC << endl;
            return true;
        }
        
        // If forwarding is disabled, check for other RAW hazards
      } else if (!knobs.Knob2) {
            // Check for RAW hazard with previous instruction
            if (ID_EX.reg_write && ID_EX.rd != 0 && 
                (ID_EX.rd == rs1 || ID_EX.rd == rs2)) {
                stats.data_hazards++;
                stats.stalls += 2;
                stats.data_stalls += 2;
                stall_cycles = 2;
                stall_flag = true;
                cout << "HAZARD: RAW hazard detected (no forwarding)" << endl;
                return true;
            }
            
            // Check for RAW hazard with instruction in MEM stage
            if (EX_MEM.reg_write && EX_MEM.rd != 0 && 
                (EX_MEM.rd == rs1 || EX_MEM.rd == rs2)) {
                stats.data_hazards++;
                stats.stalls += 1;
                stats.data_stalls += 1;
                stall_cycles = 1;
                stall_flag = true;
                cout << "HAZARD: RAW hazard detected (no forwarding)" << endl;
                return true;
            }
        }
        return false;
    }

    bool is_stalled() const {
        return stall_flag;
    }

    void clear_stall() {
        if (stall_cycles > 0) {
            stall_cycles--;
            if (stall_cycles == 0) {
                stall_flag = false;
            }
        }
    }
};

class InstructionTracker {
private:
    bool enabled;
    unsigned int tracked_instruction;
    struct StageInfo {
        int cycle;
        string stage;
        string details;
    };
    vector<StageInfo> history;

public:
    InstructionTracker() : enabled(false), tracked_instruction(0) {}

    void enable(unsigned int inst_addr) {
        enabled = true;
        tracked_instruction = inst_addr;
        history.clear();
    }

    void track_stage(unsigned int pc, const string& stage, int cycle, const string& details) {
        if (!enabled) return;
        if (pc == tracked_instruction) {
            StageInfo info;
            info.cycle = cycle;
            info.stage = stage;
            info.details = details;
            history.push_back(info);
        }
    }

    void print_history() {
        if (!enabled) return;
        cout << "\nInstruction 0x" << hex << tracked_instruction << " execution history:\n";
        for (const auto& info : history) {
            cout << "Cycle " << dec << info.cycle << ": " 
                 << info.stage << " - " << info.details << endl;
        }
    }
};

class ForwardingUnit {
  public:
      // Returns 0: no forward, 1: forward from EX/MEM, 2: forward from MEM/WB
      int forward_rs1(unsigned int rs1) {
          if (EX_MEM.reg_write && EX_MEM.rd != 0 && EX_MEM.rd == rs1) {
              return 1;
          } else if (MEM_WB.reg_write && MEM_WB.rd != 0 && MEM_WB.rd == rs1) {
              return 2;
          }
          return 0;
      }
  
      int forward_rs2(unsigned int rs2) {
          if (EX_MEM.reg_write && EX_MEM.rd != 0 && EX_MEM.rd == rs2) {
              return 1;
          } else if (MEM_WB.reg_write && MEM_WB.rd != 0 && MEM_WB.rd == rs2) {
              return 2;
          }
          return 0;
      }
  };
  

static HazardDetectionUnit HDU;
static InstructionTracker instruction_tracker;
static BranchPredictor branch_predictor;
static ForwardingUnit forward_unit;

// Function to extract opcode
unsigned int get_opcode() {
  return IF_ID.instruction & 0x7F; // Extract bits [6:0]
}
unsigned int get_funct3() {
  return (IF_ID.instruction >> 12) & 0x7; // Extract bits [14:12]
}
unsigned int get_funct7() {
  return (IF_ID.instruction >> 25) & 0x7F; // Extract bits [31:25]
}
// Function to extract register fields
unsigned int get_rs1() {
  return (IF_ID.instruction >> 15) & 0x1F; // Bits [19:15]
}
unsigned int get_rs2() {
  return (IF_ID.instruction >> 20) & 0x1F; // Bits [24:20]
}
unsigned int get_rd() {
  return (IF_ID.instruction >> 7) & 0x1F; // Bits [11:7]
}

// Function to extract immediate values
int get_immI() {
  int imm = (IF_ID.instruction >> 20) & 0xFFF; // Extract bits [31:20]
  if (imm & 0x800) {   // Check if the 12th bit is 1 (negative)
    imm |= 0xFFFFF000; // Sign-extend to 32 bits
  }
  return imm;
}
int get_immS() {
  int imm =
      ((IF_ID.instruction >> 25) << 5) |
      ((IF_ID.instruction >> 7) & 0x1F); // Combine bits [31:25] and [11:7]
  if (imm & 0x800) {   // Check if the 12th bit is 1 (negative)
    imm |= 0xFFFFF000; // Sign-extend to 32 bits
  }
  return imm;
}
int get_immB() {
  int imm;
  if (IF_ID.instruction >> 31 == 0) {
    imm = ((IF_ID.instruction >> 31) << 12) |       // bit 12 (sign)
          ((IF_ID.instruction >> 7) & 0x1) << 11 |  // bit 11
          ((IF_ID.instruction >> 25) & 0x3F) << 5 | // bits 10:5
          ((IF_ID.instruction >> 8) & 0xF) << 1;    // bits 4:1

    // Sign extension
    if (imm & 0x1000) {
      imm |= 0xFFFFE000;
    }
  } else {
    imm = ((IF_ID.instruction >> 31) << 12) | // bit 12 (sign)
          ((IF_ID.instruction >> 7) << 11) |  // bit 11
          ((IF_ID.instruction >> 25) << 5) |  // bits 10:5
          ((IF_ID.instruction >> 8) << 1);    // bits 4:1
    // Sign extend if needed
    if (imm & 0x1000) {  // Check if bit 12 is set (negative)
      imm |= 0xFFFFE000; // Sign-extend to 32 bits
    }
  }
  return imm;
}
int get_immU() {
  return IF_ID.instruction & 0xFFFFF000; // Bits [31:12]
}
int get_immJ() {
  int imm;
  if ((IF_ID.instruction >> 31) == 0) {
    // Positive offset handling
    imm = ((IF_ID.instruction >> 31) << 20) |  // Bit [31]
          ((IF_ID.instruction >> 12) & 0xFF) | // Bits [19:12]
          ((IF_ID.instruction >> 20) & 0x1) |  // Bit [20]
          ((IF_ID.instruction >> 21) & 0x3FF); // Bits [30:21]
    imm = imm << 1;
    if (imm & 0x100000) { // Check if bit 20 is set (would indicate overflow)
      imm |= 0xFFE00000;  // Sign-extend to 32 bits
    }
  } else {
    // Negative offset handling
    imm = ((IF_ID.instruction >> 31) << 20) | // Bit [31] (sign)
          ((IF_ID.instruction >> 21) << 1) |  // Bits [30:21] → [20:1]
          ((IF_ID.instruction >> 20) << 11) | // Bit [20] → bit 11
          ((IF_ID.instruction >> 12) << 12);  // Bits [19:12] → [19:12]

    // Sign extension
    if (imm & 0x100000) {
      imm |= 0xFFE00000;
    }
  }
  return imm;
}

void reset_proc() {
  for (int i = 0; i < 32; i++)
    R[i] = 0; // Reset registers

  // Initialize stack pointer (x2) to the correct value
  R[2] = STACK_POINTER; // x2 is the stack pointer register

  // Reset memories
  for (int i = 0; i < 4000; i++) {
    MEM[i] = 0;  // Reset program memory
    MEM2[i] = 0; // Reset data memory
  }
  for (int i = 0; i < 4000; i++) {
    STACK_MEM[i] = 0; // Reset stack memory
  }
  N = C = V = Z = 0; // Reset flags
  cout << "Processor reset completed." << endl;
  cout << "Stack pointer (x2) initialized to 0x" << hex << R[2] << endl;
}

// Modified read_word function to handle both memory segments
int read_word(unsigned char *mem, unsigned int address) {
  int value;
  if (address <= STACK_POINTER && address >= STACK_POINTER-16384) {
    // Access stack memory (STACK_MEM)
    unsigned int real_address = STACK_POINTER-address;
    if (real_address >= 16384) {
      cerr << "Error: Stack memory access out of bounds: " << hex << address
           << endl;
      return 0;
    }
    memcpy(&value, STACK_MEM + real_address, sizeof(value));
  } else if (address >= 0x10000000) {
    // Access data memory (MEM2)
    unsigned int real_address = address - 0x10000000;
    if (real_address >= 16388) {
      cerr << "Error: Memory access out of bounds: " << hex << address << endl;
      return 0;
    }
    memcpy(&value, MEM2 + real_address, sizeof(value));
  } else {
    // Access program memory (MEM)
    if (address >= 16388) {
      cerr << "Error: Memory access out of bounds: " << hex << address << endl;
      return 0;
    }
    memcpy(&value, mem + address, sizeof(value));
  }
  return value;
}

void write_word(unsigned char *mem, unsigned int address, unsigned int data) {
  if (address <= STACK_POINTER && address >= STACK_POINTER-16384) {
    // Access stack memory (STACK_MEM)
    unsigned int real_address = STACK_POINTER-address;
    if (real_address >= 16384) {
      cerr << "Error: Stack memory access out of bounds: " << hex << address
           << endl;
      return;
    }
    memcpy(STACK_MEM + real_address, &data, sizeof(data));
  } else if (address >= 0x10000000) {
    // Access data memory (MEM2)
    unsigned int real_address = address - 0x10000000;
    if (real_address >= 16388) {
      cerr << "Error: Memory access out of bounds: " << hex << address << endl;
      return;
    }
    memcpy(MEM2 + real_address, &data, sizeof(data));
  } else {
    // Access program memory (MEM)
    if (address >= 16388) {
      cerr << "Error: Memory access out of bounds: " << hex << address << endl;
      return;
    }
    memcpy(mem + address, &data, sizeof(data));
  }
}



// Function to write register file contents to a file
void write_register_file(const string &filename = "register_file.txt") {
  ofstream reg_file(filename);
  if (!reg_file) {
    cerr << "Error opening register file for writing: " << filename << endl;
    return;
  }

  // Write header
  reg_file << "========== RISC-V REGISTER FILE ==========\n";
  reg_file << "Register | Hexadecimal value | Decimal Value\n";
  reg_file << "-----------------------------------------\n";

  // Special register names
  string reg_names[32] = {"x0",  "x1",  "x2",  "x3",  "x4",  "x5",  "x6",
                          "x7",  "x8",  "x9",  "x10", "x11", "x12", "x13",
                          "x14", "x15", "x16", "x17", "x18", "x19", "x20",
                          "x21", "x22", "x23", "x24", "x25", "x26", "x27",
                          "x28", "x29", "x30", "x31"};

  // Write all register values
  for (int i = 0; i < 32; i++) {
    reg_file << setw(5) << setfill(' ') << left << reg_names[i] << "    | "
             << "0x" << setw(8) << setfill('0') << right << hex << R[i] << " | "

             << setw(12) << setfill(' ') << right << dec << R[i] << "\n";
  }

  // Write PC and flags
  reg_file << "\n-------- PROCESSOR STATE --------\n";
  reg_file << "PC: 0x" << setw(8) << setfill('0') << hex << PC << "\n";
  reg_file << "Clock Cycles: " << dec << clock_cycles << "\n";

  reg_file.close();
  cout << "Register file written to " << filename << endl;
}
void load_data_memory(const string &file_name) {
  ifstream fp(file_name);
  if (!fp) {
    cerr << "Error opening data memory file: " << file_name << endl;
    exit(1);
  }

  string line;
  while (getline(fp, line)) {
    // Format expected: address value (both in hex)
    line.erase(0, line.find_first_not_of(" \t\n\r\f\v"));
    if (line.empty())
      continue;

    unsigned int address, value;
    stringstream ss(line);
    ss >> hex >> address >> value;

    // Check if address is in data memory range
    if (address >= 0x10000000) {
      // Adjust address to use MEM2 with the offset
      unsigned int adjusted_address = address - 0x10000000;

      // Verify the address is within bounds
      if (adjusted_address + 3 < 16388) { // +3 for word-sized data
        write_word(MEM, address,
                   value); // Use the write_word function which handles offsets
      } else {
        cerr << "Warning: Data memory address out of bounds: 0x" << hex
             << address << " (adjusted: 0x" << adjusted_address << "), skipping"
             << endl;
      }
    } else {
      // Handle program memory if needed
      if (address + 3 < 16388) {
        write_word(MEM, address, value);
      } else {
        cerr << "Warning: Program memory address out of bounds: 0x" << hex
             << address << ", skipping" << endl;
      }
    }
  }

  fp.close();
  cout << "Data memory loaded successfully." << endl;
}

// Function to load program memory from file
void load_program_memory(const string &file_name) {
  ifstream fp(file_name);
  if (!fp) {
    cerr << "Error opening input memory file: " << file_name << endl;
    exit(1);
  }

  unsigned int address = 0; // Start address
  string line;

  while (getline(fp, line)) {
    // Remove any leading/trailing whitespace
    line.erase(0, line.find_first_not_of(" \t\n\r\f\v"));
    line.erase(line.find_last_not_of(" \t\n\r\f\v") + 1);

    // Skip empty lines
    if (line.empty()) {
      continue;
    }

    // Convert the 32-bit hexadecimal string to a 32-bit integer
    unsigned int instruction;
    stringstream ss;
    ss << hex << line;
    ss >> instruction;

    // Write the 32-bit instruction to memory
    write_word(MEM, address, instruction);
    cout << "Loading instruction: 0x" << hex << instruction << " at address: 0x"
         << address << endl;

    // Increment the address by 4 (since each instruction is 32 bits)
    address += 4;
  }

  if (fp.fail() && !fp.eof()) {
    cerr << "Error reading input memory file: Invalid format" << endl;
    exit(1);
  }

  fp.close();
  cout << "Program memory loaded successfully." << endl;
}

// Function to write data memory to file
void write_data_memory() {
  ofstream fp("data_out.mem");
  if (!fp) {
    cerr << "Error opening data_out.mem file for writing" << endl;
    return;
  }

  // Write program memory (MEM)
  fp << "========== PROGRAM MEMORY ==========\n";
  for (unsigned int i = 0; i < 4000; i += 4) {
    // Read word from program memory
    int instruction = 0;
    memcpy(&instruction, MEM + i, sizeof(instruction));

    // Format address as 8-digit hex
    fp << setw(8) << setfill('0') << hex << uppercase << i << " ";

    // Format instruction as 8-digit hex with spaces every two hex digits
    fp << setw(2) << setfill('0') << ((instruction >> 24) & 0xFF) << " "
       << setw(2) << setfill('0') << ((instruction >> 16) & 0xFF) << " "
       << setw(2) << setfill('0') << ((instruction >> 8) & 0xFF) << " "
       << setw(2) << setfill('0') << (instruction & 0xFF) << endl;
  }

  fp << "\n\n========== DATA MEMORY ==========\n";
  // Write data memory (MEM2)
  for (unsigned int i = 0; i < 4000; i += 4) {
    // Read word from data memory
    int data = 0;
    memcpy(&data, MEM2 + i, sizeof(data));

    // Format address as 8-digit hex (with the 0x10000000 offset)
    fp << setw(8) << setfill('0') << hex << uppercase << (i + 0x10000000)
       << " ";

    // Format data as 8-digit hex with spaces every two hex digits
    fp << setw(2) << setfill('0') << ((data >> 24) & 0xFF) << " " << setw(2)
       << setfill('0') << ((data >> 16) & 0xFF) << " " << setw(2)
       << setfill('0') << ((data >> 8) & 0xFF) << " " << setw(2) << setfill('0')
       << (data & 0xFF) << endl;
  }

  fp << "\n\n========== STACK MEMORY ==========\n";
  // Write stack memory (STACK_MEM) - Modified to display the full stack range
  for (unsigned int i = 0; i < 4000; i += 4) {
    // Read word from stack memory
    int stack_data = 0;
    memcpy(&stack_data, STACK_MEM + i, sizeof(stack_data));

    // Format address as 8-digit hex (with the STACK_TOP offset)
    fp << setw(8) << setfill('0') << hex << uppercase << (STACK_POINTER - i ) << " ";

    // Format data as 8-digit hex with spaces every two hex digits
    fp << setw(2) << setfill('0') << ((stack_data >> 24) & 0xFF) << " "
       << setw(2) << setfill('0') << ((stack_data >> 16) & 0xFF) << " "
       << setw(2) << setfill('0') << ((stack_data >> 8) & 0xFF) << " "
       << setw(2) << setfill('0') << (stack_data & 0xFF) << endl;
  }
  fp.close();
  cout << "Data memory written to data_out.mem" << endl;
}
// should be called when instruction is swi_exit
void swi_exit() {
  write_data_memory();

  exit(0);
}
// Pipeline control functions
void flush_pipeline() {
  IF_ID.valid = false;
  ID_EX.valid = false;
  EX_MEM.valid = false;
  MEM_WB.valid = false;
}

void stall_pipeline() {
  PC -= 4;  // "Unfetch" the instruction
   

    // Insert bubble in ID/EX stage
    ID_EX = {};
    ID_EX.valid = false;
}

// reads from the instruction memory and updates the instruction register
void fetch() {
IF_ID.PC = PC; // Update PC in IF_ID register
  IF_ID.instruction = read_word(MEM, PC);
  bool is_branch = ((IF_ID.instruction & 0x7F) == 0x63);  // Branch opcode
  bool is_jump = ((IF_ID.instruction & 0x7F) == 0x6F || (IF_ID.instruction & 0x7F) == 0x67);  // JAL/JALR opcodes
  
  if ((is_branch || is_jump) && knobs.Knob6) {
      bool predicted_taken = branch_predictor.predict(PC);
      if (predicted_taken) {
          // Change PC to predicted target
          PC = branch_predictor.get_target(PC);
          cout << "FETCH: Branch predicted taken, redirecting to " << hex << PC << endl;
      }
  }
  cout << "FETCH: Instruction " << hex << IF_ID.instruction << " at PC " << hex
       << PC << endl;
      if (IF_ID.instruction == 0xFFFFFFFF) {
        cout << "Simulation halted." << endl;  
        end_of_program = true; // Set the end_of_program flag
        IF_ID.valid = false; // Invalidate the instruction register
        IF_ID.instruction = 0; // Clear the instruction register
        return; // Exit the fetch stage 
      }
  PC += 4; // Increment PC to next instruction
  cout << "####### End Fetch #########" << endl;
}
// reads the instruction register, reads operand1, operand2 fromo register file,
// decides the operation to be performed in execute stage
void decode() {
  ID_EX.PC = IF_ID.PC; // Update PC in ID_EX register
  ID_EX.opcode = get_opcode();
  unsigned int rs1 = get_rs1();
unsigned int rs2 = get_rs2();
if (HDU.detect_hazard(rs1, rs2)) {
    cout << "DECODE: Hazard detected. Stalling pipelinen"<<endl;
    stall_pipeline();  // Prevent IF from moving forward
   
    return; // Stop decode stage
}
ID_EX.valid = true; // Mark ID_EX as valid
  char format;
  if (ID_EX.opcode == 0b0110011) {
    format = 'R';
    stats.alu_inst++;
  } else if (ID_EX.opcode == 0b0010011 || ID_EX.opcode == 0b0000011 ||
             ID_EX.opcode == 0b1100111 || ID_EX.opcode == 0b1110011) {
    format = 'I';
  } else if (ID_EX.opcode == 0b0100011) {
    format = 'S';
    stats.data_transfer_inst++;
  } else if (ID_EX.opcode == 0b1100011) {
    format = 'B';
    stats.control_inst++;
  } else if (ID_EX.opcode == 0b1101111) {
    format = 'J';
    stats.control_inst++; 
  } else if (ID_EX.opcode == 0b0010111 || ID_EX.opcode == 0b0110111) {
    format = 'U';
    stats.alu_inst++;

  } else {
    format = 'Z';
  }

  switch (format) {
  case 'R': {
    ID_EX.funct3 = get_funct3();
    ID_EX.funct7 = get_funct7();
    switch (ID_EX.funct3) {
    case 0b000:
      if (ID_EX.funct7 == 0b00000000) {
        ID_EX.ALU_op = 0;
        cout << "Operation is ADD" << endl;
      } else if (ID_EX.funct7 == 0b00000001) { // <-- NEW: Multiply extension
        ID_EX.ALU_op = 25;
        cout << "Operation is MUL" << endl;
      } else {
        ID_EX.ALU_op = 1;
        cout << "Operation is SUB" << endl;
      }
      break;
    case 0b001:
      ID_EX.ALU_op = 2;
      cout << "Operation is SLL" << endl;
      break;
    case 0b010:
      ID_EX.ALU_op = 3;
      cout << "Operation is SLT" << endl;
      break;
    case 0b100:
      ID_EX.ALU_op = 4;
      cout << "Operation is XOR" << endl;
      break;
    case 0b101:
      if (ID_EX.funct7 == 0b00000000) {
        ID_EX.ALU_op = 5;
        cout << "Operation is SRL" << endl;
      } else {
        ID_EX.ALU_op = 6;
        cout << "Operation is SRA" << endl;
      }
      break;
    case 0b110:
      ID_EX.ALU_op = 7;
      cout << "Operation is OR" << endl;
      break;
    case 0b111:
      ID_EX.ALU_op = 8;
      cout << "Operation is AND" << endl;
      break;
    default:
      cout << "Invalid funct3" << endl;
    }
    ID_EX.Result_select = 3;
    ID_EX.mem_write = false;
    ID_EX.mem_read = false;
    ID_EX.reg_write = true;
    ID_EX.rs1 = R[get_rs1()];
    ID_EX.rs2 = R[get_rs2()];
    
    ID_EX.rd = get_rd();
    cout << "DECODE: Operands: x" << dec << get_rs1() << " = " << ID_EX.rs1
         << " , x" << dec << get_rs2() << " = " << ID_EX.rs2 << endl;
    cout << "Destination register: x" << dec << ID_EX.rd << endl;

  } break;
  case 'I': {
    ID_EX.funct3 = get_funct3();
    int bit4 = (ID_EX.opcode >> 4) & 0x1;
    int bit6 = (ID_EX.opcode >> 6) & 0x1;
    if (bit4 == 1) {
      stats.alu_inst++;
      switch (ID_EX.funct3) {
      case 0b000:
        ID_EX.ALU_op = 9;
        cout << "Operation is ADDI" << endl;
        break;
      case 0b001:
        ID_EX.ALU_op = 10;
        cout << "Operation is SLLI" << endl;
        break;
      case 0b010:
        ID_EX.ALU_op = 11;
        cout << "Operation is SLTI" << endl;
        break;
      case 0b100:
        ID_EX.ALU_op = 12;
        cout << "Operation is XORI" << endl;
        break;
      case 0b101:
        ID_EX.funct7 = get_funct7();
        if (ID_EX.funct7 == 0b00000000) {
          ID_EX.ALU_op = 13;
          cout << "Operation is SRLI" << endl;
        } else {
          ID_EX.ALU_op = 14;
          cout << "Operation is SRAI" << endl;
        }
        break;
      case 0b110:
        ID_EX.ALU_op = 15;
        cout << "Operation is ORI" << endl;
        break;
      case 0b111:
        ID_EX.ALU_op = 16;
        cout << "Operation is ANDI" << endl;
        break;
      default:
        cout << "Invalid funct3" << endl;
      }
      ID_EX.Result_select = 3;
      ID_EX.mem_write = false;
      ID_EX.mem_read = false;
      ID_EX.reg_write = true;
    } else if (bit6 == 0) { // load
     stats.data_transfer_inst++;
      ID_EX.ALU_op = 0;
      cout << "Operation is Load" << endl;

      ID_EX.Result_select = 2; // Load data from memory
      ID_EX.mem_write = false;
      ID_EX.mem_read = true;
      ID_EX.reg_write = true;
    } else {
      stats.control_inst++;
      cout << "Operation is JALR" << endl;
      ID_EX.ALU_op = 17;
      ID_EX.Result_select = 0; // ALU result
      ID_EX.mem_write = false;
      ID_EX.mem_read = false;
      ID_EX.reg_write = true;
    }
    ID_EX.rs1 = R[get_rs1()];
    ID_EX.immI = (get_immI());
    ID_EX.rs2 = ID_EX.immI;
    ID_EX.rd = get_rd();
    cout << "DECODE: Operands: x" << dec << get_rs1() << " = " << ID_EX.rs1
         << " , Immediate operand " << dec << ID_EX.immI << endl;
    cout << "Destination register: x" << dec << ID_EX.rd << endl;

  } break;

  case 'S': {
    ID_EX.funct3 = get_funct3();
    ID_EX.ALU_op = 0;

    ID_EX.mem_write = true;
    ID_EX.mem_read = false;
    ID_EX.reg_write = false;

    ID_EX.rs1 = R[get_rs1()];
    ID_EX.immS = (get_immS());
    ID_EX.rs2 = ID_EX.immS;
    ID_EX.rs2_reg = get_rs2(); // Store the value of rs2 for later use
    cout << "DECODE: Store Instruction" << endl;
    cout << " First operand: x" << dec << get_rs1() << " = " << ID_EX.rs1
         << " , Immediate operand = " << dec << ID_EX.immS << endl;
  } break;
  case 'B': {
    ID_EX.funct3 = get_funct3();
    ID_EX.reg_write = false;
    ID_EX.mem_write = false;
    ID_EX.mem_read = false;
    ID_EX.rs1 = R[get_rs1()];
    ID_EX.rs2 = R[get_rs2()];
    ID_EX.immB = (get_immB());
    switch (ID_EX.funct3) {
    case 0: {
      ID_EX.ALU_op = 18;
      cout << "BEQ";
    } break;
    case 1: {
      cout << "BNE";
      ID_EX.ALU_op = 19;
    } break;
    case 4: {
      cout << "BLT";
      ID_EX.ALU_op = 20;

    } break;
    case 5: {
      cout << "BGE";
      ID_EX.ALU_op = 21;
    } break;

    default: {
      cerr << "Error: Could not identify instruction.\n";
      break;
    } break;
    }
    cout << "\nFirst Operand X" << dec << get_rs1() << ", Second Operand X"
         << dec << get_rs2() << endl;
    cout << "DECODE: "
         << "Read Register X" << dec << get_rs1() << " = " << ID_EX.rs1 << ", X"
         << dec << get_rs2() << " = " << ID_EX.rs2 << ", ID_EX.imm = " << dec
         << ID_EX.immB << endl;

  } break;

  case 'J': {
    ID_EX.rd = get_rd();
    ID_EX.immJ = get_immJ();

    ID_EX.mem_write = false;
    ID_EX.mem_read = false;
    ID_EX.ALU_op = 24; // Set ALU operation for JAL
    ID_EX.Result_select = 0; // JAL result
    ID_EX.reg_write = true; // Write to register file

    cout << "DECODE: JAL" << endl;
    cout << "Destination Register X" << dec << ID_EX.rd << ", immJ = " << dec
         << ID_EX.immJ << endl;
  } break;
  case 'U': {
    ID_EX.rd = get_rd();
    ID_EX.immU = get_immU();
    int bit5 = (ID_EX.opcode >> 5) & 0x1;

    if (bit5 == 1) { // LUI
      cout << "LUI\n";
      ID_EX.ALU_op = 22; // Set ALU operation for LUI
      ID_EX.Result_select = 1; // ALU result
      ID_EX.mem_write = false;
      ID_EX.mem_read = false;
      ID_EX.reg_write = true; // Write to register file
      cout << "DECODE: Destination Register X" << dec << ID_EX.rd << endl;
      cout << "immU = " << dec << ID_EX.immU << endl;

    } else { // AUIPC
      cout << "AUIPC\n";
      ID_EX.ALU_op = 23; // Set ALU operation for AUIPC (ADD)
      ID_EX.Result_select = 1; // ALU result
      ID_EX.mem_write = false;
      ID_EX.mem_read = false;
      ID_EX.reg_write = true; // Write to register file

      ID_EX.rs1 = ID_EX.immU; // First operand is immU
      ID_EX.rs2 = PC;        // Second operand is PC

      cout << "DECODE: Destination Register X" << dec << ID_EX.rd << endl;
      cout << "First Operand immU = " << dec << ID_EX.immU
           << ", Second Operand PC = " << PC << endl;
    }

  } break;
  default:
    cerr << "Error: Could not identify instruction.\n";
    break;
  }

  cout << "####### End Decode #########" << endl;
}
// executes the ALU operation based on ALUop
void execute() {
  EX_MEM.PC = ID_EX.PC; // Update PC in EX_MEM register

  unsigned int rs1_value = ID_EX.rs1; // Default value
  unsigned int rs2_value = ID_EX.rs2; // Default value
  
  if (knobs.Knob2) {
    // Forward for rs1
    int fwd_rs1 = forward_unit.forward_rs1(get_rs1());
    if (fwd_rs1 == 1) {
      // Forward from EX/MEM
      rs1_value = EX_MEM.ALU_result;
      cout << "FORWARDING: EX/MEM -> rs1 (x" << get_rs1() << ") = " << rs1_value << endl;
    } else if (fwd_rs1 == 2) {
      // Forward from MEM/WB
      rs1_value = MEM_WB.ALU_result;
      cout << "FORWARDING: MEM/WB -> rs1 (x" << get_rs1() << ") = " << rs1_value << endl;
    }
    
    // Forward for rs2 (only for R-type and branch instructions)
    if (ID_EX.opcode == 0b0110011 || ID_EX.opcode == 0b1100011) {
      int fwd_rs2 = forward_unit.forward_rs2(get_rs2());
      if (fwd_rs2 == 1) {
        // Forward from EX/MEM
        rs2_value = EX_MEM.ALU_result;
        cout << "FORWARDING: EX/MEM -> rs2 (x" << get_rs2() << ") = " << rs2_value << endl;
      } else if (fwd_rs2 == 2) {
        // Forward from MEM/WB
        rs2_value = MEM_WB.ALU_result;
        cout << "FORWARDING: MEM/WB -> rs2 (x" << get_rs2() << ") = " << rs2_value << endl;
      }
    }
    
    
    // For store instructions, forward the register value to be stored
    if (ID_EX.mem_write) {
      int fwd_rs2 = forward_unit.forward_rs2(ID_EX.rs2_reg);
      if (fwd_rs2 == 1) {
        // Forward from EX/MEM
        EX_MEM.rs2_val = EX_MEM.ALU_result;
        cout << "FORWARDING: EX/MEM -> store value (x" << ID_EX.rs2_reg << ") = " << EX_MEM.rs2_val << endl;
      } else if (fwd_rs2 == 2) {
        // Forward from MEM/WB
        EX_MEM.rs2_val = MEM_WB.ALU_result;
        cout << "FORWARDING: MEM/WB -> store value (x" << ID_EX.rs2_reg << ") = " << EX_MEM.rs2_val << endl;
        }}}



  switch (ID_EX.ALU_op) {
  // R-type instructions
  case 0:
    EX_MEM.ALU_result = rs1_value + rs2_value;

    cout << "EXECUTE: " << rs1_value << " + " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 1:
    EX_MEM.ALU_result = rs1_value - rs2_value;

    cout << "EXECUTE: " << rs1_value << " - " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 2:
    EX_MEM.ALU_result = rs1_value << rs2_value;

    cout << "EXECUTE: " << rs1_value << " << " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 3:
    EX_MEM.ALU_result =
        static_cast<int>(rs1_value) < static_cast<int>(rs2_value);

    cout << "EXECUTE: " << rs1_value << " < " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 4:
    EX_MEM.ALU_result = rs1_value ^ rs2_value;

    cout << "EXECUTE: " << rs1_value << " ^ " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 5:
    EX_MEM.ALU_result = rs1_value >> rs2_value;

    cout << "EXECUTE: " << rs1_value << " >> " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 6:
    EX_MEM.ALU_result = static_cast<int>(rs1_value) >> rs2_value;

    cout << "EXECUTE: " << rs1_value << " >> " << rs2_value << " (arithmetic)"
         << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 7:
    EX_MEM.ALU_result = rs1_value | rs2_value;

    cout << "EXECUTE: " << rs1_value << " | " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 8:
    EX_MEM.ALU_result = rs1_value & rs2_value;

    cout << "EXECUTE: " << rs1_value << " & " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
    
  // I-type instructions
  case 9: // ADDI
    EX_MEM.ALU_result = rs1_value + ID_EX.immI;

    cout << "EXECUTE: " << rs1_value << " + " << ID_EX.immI << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 10: // SLLI
    EX_MEM.ALU_result = rs1_value << (ID_EX.immI & 0x1F);

    cout << "EXECUTE: " << rs1_value << " << " << (ID_EX.immI & 0x1F) << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 11: // SLTI
    EX_MEM.ALU_result =
        (static_cast<int>(rs1_value) < static_cast<int>(ID_EX.immI)) ? 1 : 0;

    cout << "EXECUTE: " << rs1_value << " < " << ID_EX.immI << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 12: // XORI
    EX_MEM.ALU_result = rs1_value ^ ID_EX.immI;

    cout << "EXECUTE: " << rs1_value << " ^ " << ID_EX.immI << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 13: // SRLI
    EX_MEM.ALU_result = rs1_value >> (ID_EX.immI & 0x1F);

    cout << "EXECUTE: " << rs1_value << " >> " << (ID_EX.immI & 0x1F) << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 14: // SRAI
    EX_MEM.ALU_result = static_cast<int>(rs1_value) >> (ID_EX.immI & 0x1F);

    cout << "EXECUTE: " << rs1_value << " >> " << (ID_EX.immI & 0x1F)
         << " (arithmetic)" << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 15: // ORI
    EX_MEM.ALU_result = rs1_value | ID_EX.immI;

    cout << "EXECUTE: " << rs1_value << " | " << ID_EX.immI << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 16: // ANDI
    EX_MEM.ALU_result = rs1_value & ID_EX.immI;

    cout << "EXECUTE: " << rs1_value << " & " << ID_EX.immI << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 17: // JALR

    ID_EX.branch_target =
        (rs1_value + ID_EX.immI) & ~1; // Clear the least significant bit
    EX_MEM.ALU_result = PC;
    

    ID_EX.branch = true; // Indicate this is a branch/jump instruction
    ID_EX.branch_taken = true;
    cout << "EXECUTE: " << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    cout << "Branch target: " << ID_EX.branch_target << endl;
    break;

  // B-type instructions
  case 18: // BEQ
    ID_EX.branch = true;
    ID_EX.branch_taken = (rs1_value == rs2_value);
    cout << "EXECUTE: Comparing " << rs1_value << " == " << rs2_value << endl;
    cout << "Branch " << (ID_EX.branch_taken ? "taken" : "not taken") << endl;
    if (ID_EX.branch_taken) {
      ID_EX.branch_target = PC + ID_EX.immB - 4;
      cout << "Branch target: " << ID_EX.branch_target << endl;
    }
    break;
  case 19: // BNE
    ID_EX.branch = true;
    ID_EX.branch_taken = (rs1_value != rs2_value);
    cout << "EXECUTE: Comparing " << rs1_value << " != " << rs2_value << endl;
    cout << "Branch " << (ID_EX.branch_taken ? "taken" : "not taken") << endl;
    if (ID_EX.branch_taken) {
      ID_EX.branch_target = PC + ID_EX.immB - 4;
      cout << "Branch target: " << ID_EX.branch_target << endl;
    }
    break;
  case 20: // BLT
    ID_EX.branch = true;
    ID_EX.branch_taken =
        (static_cast<int>(rs1_value) < static_cast<int>(rs2_value)) ? 1 : 0;
    cout << "EXECUTE: Comparing " << rs1_value << " < " << rs2_value << endl;
    cout << "Branch " << (ID_EX.branch_taken ? "taken" : "not taken") << endl;
    if (ID_EX.branch_taken) {
      ID_EX.branch_target = PC + ID_EX.immB - 4;
      cout << "Branch target: " << ID_EX.branch_target << endl;
    }
    break;
  case 21: // BGE
    ID_EX.branch = true;
    ID_EX.branch_taken =
        (static_cast<int>(rs1_value) >= static_cast<int>(rs2_value)) ? 1 : 0;
    ID_EX.branch_target = PC + ID_EX.immB - 4;
    cout << "EXECUTE: Comparing " << rs1_value << " >= " << rs2_value << endl;
    cout << "Branch " << (ID_EX.branch_taken ? "taken" : "not taken") << endl;
    if (ID_EX.branch_taken) {
      cout << "Branch target: " << ID_EX.branch_target << endl;
    }
    break;

  // U-type instructions
  case 22: // LUI
    EX_MEM.ALU_result = ID_EX.immU;

    cout << "EXECUTE: Loading upper immediate " << ID_EX.immU << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
  case 23: // AUIPC
    EX_MEM.ALU_result = PC + ID_EX.immU - 4;

    cout << "EXECUTE: " << PC - 4 << " + " << ID_EX.immU << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;

  // J-type instruction
  case 24: // JAL
    EX_MEM.ALU_result = PC;
    ID_EX.branch_target = (PC - 4) + ID_EX.immJ;
    ID_EX.branch = true;
    ID_EX.branch_taken = true;
   

    cout << "EXECUTE:" << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    cout << "Jump target: " << hex << ID_EX.branch_target << endl;
    break;
  case 25: // MUL
    EX_MEM.ALU_result = rs1_value * rs2_value;

    cout << "EXECUTE: " << rs1_value << " * " << rs2_value << endl;
    cout << "Result: " << EX_MEM.ALU_result << " in x" << ID_EX.rd << endl;
    break;
    // Load/Store operations
    // For these, the ALU computes the effective address
    // Note: If ALU == 0, this could be either ADD or Load/Store

  default:
    cout << "Invalid ALU operation" << endl;
  }

  // Handle load instructions
  if (EX_MEM.mem_read) {
    EX_MEM.ALU_result = rs1_value + ID_EX.immI; // Calculate effective address

    cout << "EXECUTE: Load operation, address = " << rs1_value << " + "
         << ID_EX.immI << " = " << EX_MEM.ALU_result << endl;
  }

  // Handle store instructions
  if (EX_MEM.mem_write) {
    EX_MEM.ALU_result = rs1_value + ID_EX.immS; // Calculate effective address

    cout << "EXECUTE: Store operation, address = " << rs1_value << " + "
         << ID_EX.immS << " = " << EX_MEM.ALU_result << endl;
  }
  EX_MEM.mem_read = ID_EX.mem_read;
  EX_MEM.mem_write = ID_EX.mem_write;
  EX_MEM.rd = ID_EX.rd;  // Forward destination register
  // At the end of execute()
EX_MEM.rs2_val = ID_EX.rs2_reg;  // Add this line
EX_MEM.reg_write = ID_EX.reg_write;
EX_MEM.valid = ID_EX.valid;

  EX_MEM.branch = ID_EX.branch; // Forward branch information
  EX_MEM.branch_taken = ID_EX.branch_taken; // Forward branch taken information
  EX_MEM.branch_target = ID_EX.branch_target; // Forward branch target address

  // Clear the stall condition in the hazard detection unit
//HDU.clear_stall();

  cout << "####### End Execute #########" << endl;
}

// perform the memory operation
void mem() {
  MEM_WB.PC = EX_MEM.PC; // Update PC in MEM_WB register
  if (EX_MEM.mem_write) { // Store operation
    cout << "MEMORY: Store operation at address 0x" << hex << EX_MEM.ALU_result
         << endl;
    unsigned char *target_mem;
    unsigned int adjusted_address;
    unsigned int store_value = R[EX_MEM.rs2_val]; // Value to be stored
    if (EX_MEM.ALU_result <= STACK_POINTER && EX_MEM.ALU_result >= STACK_POINTER-16384) {
      // STACK_MEM
      target_mem = STACK_MEM;
      adjusted_address = STACK_POINTER-EX_MEM.ALU_result ;
      cout << "Using stack memory segment (STACK_MEM)" << endl;
    } else if (EX_MEM.ALU_result >= 0x10000000) {
      // Data memory access (MEM2)
      target_mem = MEM2;
      adjusted_address = EX_MEM.ALU_result - 0x10000000;
      cout << "Using data memory segment (MEM2)" << endl;
    } else {
      // Program memory access (MEM)
      target_mem = MEM;
      adjusted_address = EX_MEM.ALU_result;
      cout << "Using program memory segment (MEM)" << endl;
    }

    switch (ID_EX.funct3) {
    case 0b000: // SB - Store Byte
      target_mem[adjusted_address] = EX_MEM.rs2_val & 0xFF;
      cout << "Storing byte: 0x" << hex << (EX_MEM.rs2_val & 0xFF) << endl;
      break;
    case 0b001: // SH - Store Halfword
      target_mem[adjusted_address] = EX_MEM.rs2_val & 0xFF;
      target_mem[adjusted_address + 1] = (EX_MEM.rs2_val >> 8) & 0xFF;
      cout << "Storing halfword: 0x" << hex << (EX_MEM.rs2_val & 0xFFFF)
           << endl;
      break;
    case 0b010: // SW - Store Word
      target_mem[adjusted_address] = R[EX_MEM.rs2_val] & 0xFF;
      target_mem[adjusted_address + 1] = (R[EX_MEM.rs2_val] >> 8) & 0xFF;
      target_mem[adjusted_address + 2] = (R[EX_MEM.rs2_val] >> 16) & 0xFF;
      target_mem[adjusted_address + 3] = (R[EX_MEM.rs2_val] >> 24) & 0xFF;
      cout << "Storing word: 0x" << hex << R[EX_MEM.rs2_val] << endl;
      break;
    default:
      cout << "Invalid store operation" << endl;
      break;
    }
  } else if (!ID_EX.branch && EX_MEM.mem_read) { // Load operation
    cout << "MEMORY: Load operation from address 0x" << hex << EX_MEM.ALU_result
         << endl;
    unsigned char *target_mem;
    unsigned int adjusted_address;

    if (EX_MEM.ALU_result <= STACK_POINTER && EX_MEM.ALU_result >= STACK_POINTER-16384){
      target_mem = STACK_MEM;
      adjusted_address = STACK_POINTER - EX_MEM.ALU_result;
      cout << "Using stack memory segment (STACK_MEM)"<<endl;
  } else if (EX_MEM.ALU_result >= 0x10000000) {
      // Data memory access (MEM2)
      target_mem = MEM2;
      adjusted_address = EX_MEM.ALU_result - 0x10000000;
      cout << "Using data memory segment (MEM2)" << endl;
    } else {
      // Program memory access (MEM)
      target_mem = MEM;
      adjusted_address = EX_MEM.ALU_result;
      cout << "Using program memory segment (MEM)" << endl;
    }

    switch (ID_EX.funct3) {
    case 0b000: // LB - Load Byte
      EX_MEM.ALU_result =
          static_cast<int8_t>(target_mem[adjusted_address]); // Sign-extend
      cout << "Loaded byte (sign-extended): 0x" << hex << EX_MEM.ALU_result
           << endl;
      break;
    case 0b001: // LH - Load Halfword
      EX_MEM.ALU_result = static_cast<int16_t>(
          target_mem[adjusted_address] |
          (target_mem[adjusted_address + 1] << 8)); // Sign-extend
      cout << "Loaded halfword (sign-extended): 0x" << hex << EX_MEM.ALU_result
           << endl;
      break;
    case 0b010: // LW - Load Word
      EX_MEM.ALU_result = target_mem[adjusted_address] |
                          (target_mem[adjusted_address + 1] << 8) |
                          (target_mem[adjusted_address + 2] << 16) |
                          (target_mem[adjusted_address + 3] << 24);
      cout << "Loaded word: 0x" << hex << EX_MEM.ALU_result << endl;
      break;
    case 0b100: // LBU - Load Byte Unsigned
      EX_MEM.ALU_result = target_mem[adjusted_address] & 0xFF; // Zero-extend
      cout << "Loaded byte (zero-extended): 0x" << hex << EX_MEM.ALU_result
           << endl;
      break;
    case 0b101: // LHU - Load Halfword Unsigned
      EX_MEM.ALU_result = (target_mem[adjusted_address] |
                           (target_mem[adjusted_address + 1] << 8)) &
                          0xFFFF; // Zero-extend
      cout << "Loaded halfword (zero-extended): 0x" << hex << EX_MEM.ALU_result
           << endl;
      break;
    default:
      cout << "Invalid load operation" << endl;
      break;
    }
  } else {
    cout << "No memory Operation"<<endl;
  }
  // Update PC for branches and jumps

// In mem() function where branches are handled
if (EX_MEM.branch) {
    unsigned int branch_pc = EX_MEM.PC;
    
    // Check if this is first encounter
    bool is_first_encounter = (branch_predictor.PHT.find(branch_pc) == branch_predictor.PHT.end() ||
                              branch_predictor.bpob_predicted[branch_pc].length() == 0);
    
    // Get the prediction that was made
    char prediction = is_first_encounter ? 'N' : branch_predictor.PHT[branch_pc];
    bool predicted_taken = (prediction == 'T');
    
    // Get actual outcome
    bool actual_taken = EX_MEM.branch_taken;
    char actual = actual_taken ? 'T' : 'N';
    
    // Check for misprediction
    bool misprediction = (prediction != actual);
    
    cout << "MEMORY: Branch at 0x" << hex << branch_pc 
         << " - predicted " << (predicted_taken ? "TAKEN" : "NOT TAKEN") 
         << ", actual " << (actual_taken ? "TAKEN" : "NOT TAKEN")
         << (is_first_encounter ? " (FIRST ENCOUNTER)" : "") 
         << " -> " << (misprediction ? "MISPREDICTION" : "CORRECT") << endl;
    
    // Update statistics on misprediction
    if (misprediction) {
        stats.branch_mispredictions++;
        stats.control_hazards++;
        stats.control_stalls++;
        stats.stalls++;
        
        cout << "MEMORY: BRANCH MISPREDICTION at PC 0x" << hex << branch_pc << endl;
        
        // Pipeline flush on misprediction
        IF_ID.valid = false;
        ID_EX.valid = false;
        
        // Update PC to correct target
        PC = EX_MEM.branch_taken ? EX_MEM.branch_target : EX_MEM.PC + 4;
        cout << "MEMORY: Correcting PC to 0x" << hex << PC << endl;
    }
    
    // Always update the branch predictor with actual outcome
    branch_predictor.update(branch_pc, EX_MEM.branch_taken, EX_MEM.branch_target);
}
  MEM_WB.rd = EX_MEM.rd;  // Forward destination register
MEM_WB.reg_write = EX_MEM.reg_write;
MEM_WB.ALU_result = EX_MEM.ALU_result;
MEM_WB.valid = EX_MEM.valid;
MEM_WB.mem_read = EX_MEM.mem_read;
  // Reset memory control signals after use
  EX_MEM.mem_read = false;
  EX_MEM.mem_write = false;
  



  cout << "####### End Memory #########" << endl;
}
// writes the results back to register file
void write_back() {
  

  if (MEM_WB.reg_write && MEM_WB.rd != 0) { // Don't write to x0
    switch (ID_EX.Result_select) {     
        case 0:            // PC+4 (for JAL/JALR)
         R[MEM_WB.rd] = MEM_WB.ALU_result;
          cout << "WRITEBACK: Writing Return Address " << MEM_WB.ALU_result
           << " to x" << MEM_WB.rd << endl;
           break;

    case 1:{ // Immediate result
      R[MEM_WB.rd] = MEM_WB.ALU_result;
      cout << "WRITEBACK: Writing immediate value " << dec << MEM_WB.ALU_result
           << " to x" << MEM_WB.rd << endl;
           break;

    } case 2: { // Memory load result
      R[MEM_WB.rd] = MEM_WB.ALU_result;
      cout << "WRITEBACK: Writing memory loaded value " << dec
           << MEM_WB.ALU_result << " to x" << MEM_WB.rd << endl;
           break;

    } case 3: { // ALU result
      R[MEM_WB.rd] = MEM_WB.ALU_result;
      cout << "WRITEBACK: Writing ALU result " << dec << MEM_WB.ALU_result
           << " to x" << MEM_WB.rd << endl;
           break;
    } default:
        cout << "WRITEBACK: Invalid result selection" << endl;
              break;
   }

  } else if (!MEM_WB.reg_write) {
    cout << "WRITEBACK: No register write" << endl;
  } else {
    cout << "WRITEBACK: Attempted write to x0 (ignored)" << endl;
  }

  // Update flags based on the ALU_Result
  Z = (MEM_WB.ALU_result == 0) ? 1 : 0; // Zero flag
  N = (MEM_WB.ALU_result < 0) ? 1 : 0;  // Negative flag

  ID_EX.branch = false;      // Reset branch flag
    ID_EX.branch_taken = false;  // Reset branch taken flag


  

  cout << "####### End Writeback #########" << endl;
  cout << endl;
}
void print_pipeline_registers() {
  cout << "===== PIPELINE REGISTER STATE @ Cycle " << dec << clock_cycles << " =====" << endl;

  // IF/ID
  cout << "IF/ID:\n";
  cout << "  PC = 0x" << hex << IF_ID.PC << ", Instruction = 0x" << IF_ID.instruction << ", Valid = " << IF_ID.valid << endl;

  // ID/EX
  cout << "ID/EX:\n";
  cout << "  PC = 0x" << hex << ID_EX.PC << ", rs1 = " << ID_EX.rs1 << ", rs2 = " << ID_EX.rs2
       << ", rd = " << ID_EX.rd << ", immI = " << ID_EX.immI << ", ALU_op = " << ID_EX.ALU_op << endl;
  cout << "  Control signals: mem_read = " << ID_EX.mem_read << ", mem_write = " << ID_EX.mem_write
       << ", reg_write = " << ID_EX.reg_write << ", branch = " << ID_EX.branch << endl;

  // EX/MEM
  cout << "EX/MEM:\n";
  cout << "  PC = 0x" << hex << EX_MEM.PC << ", ALU_result = " << EX_MEM.ALU_result
       << ", rs2_val = " << EX_MEM.rs2_val << ", rd = " << EX_MEM.rd << ", Valid = " << EX_MEM.valid << endl;

  // MEM/WB
  cout << "MEM/WB:\n";
  cout << "  PC = 0x" << hex << MEM_WB.PC << ", ALU_result = " << MEM_WB.ALU_result
       << ", mem_data = " << MEM_WB.mem_data << ", rd = " << MEM_WB.rd << ", Valid = " << MEM_WB.valid << endl;

  cout << "===============================================\n";
}
void print_branch_predictor_state() {
  cout << "===== BRANCH PREDICTION STATE @ Cycle " << dec << clock_cycles << " =====" << endl;
  cout << "Current PC: 0x" << hex << PC << endl;
  
  cout << "Prediction History Table (PHT):" << endl;
  for (const auto& entry : branch_predictor.PHT) {
      cout << "PC = 0x" << hex << entry.first << " -> Prediction: " 
           << (entry.second == 'T' ? "TAKEN" : "NOT TAKEN");
      
      // Show history if available
      if (!branch_predictor.bpob_predicted[entry.first].empty()) {
          cout << " (History: Predicted=\"" << branch_predictor.bpob_predicted[entry.first] 
               << "\", Actual=\"" << branch_predictor.bpob_actual[entry.first] << "\")";
      }
      cout << endl;
  }
  
  cout << "Branch Target Buffer (BTB):" << endl;
  for (const auto& entry : branch_predictor.BTB) {
      cout << "PC = 0x" << hex << entry.first << " -> Target Address: 0x" 
           << entry.second << endl;
  }
  
  cout << "===============================================" << endl;
}
void run_RISCVsim() {
  if (knobs.Knob1) {
    // PIPELINED MODE
    
    while (1) {
      clock_cycles++;
      cout << "===== CLOCK CYCLE " << clock_cycles << " =====" << endl;
      write_back();
      mem();
      execute();

       

      if (!HDU.is_stalled()){
      decode();
      fetch();
      } else {
        cout << "===== STALL IN CYCLE " << clock_cycles << " =====" << endl;
        cout << "REASON: Data hazard detected - RAW dependency" << endl;
        cout << "ACTION: Skipping fetch and decode in this cycle" << endl;
        cout << "=========================================" << endl;
        HDU.clear_stall();
      }
// Check if it's time to end the simulation
if (end_of_program && 
  !IF_ID.valid && !ID_EX.valid && !EX_MEM.valid && !MEM_WB.valid) {
  cout << "Pipeline drained. Simulation complete." << endl;
  break;
}
      if (knobs.Knob3) {
        string filename = "register_cycle_" + to_string(clock_cycles) + ".txt";
        write_register_file(filename);
    }
    if (knobs.Knob4) {
      print_pipeline_registers();
  }
  if (knobs.Knob5 > 0) {
    unsigned int target_pc = (knobs.Knob5 - 1) * 4;
    // if our watched PC is sitting in any pipeline register:
    if (IF_ID.PC == target_pc ||
        ID_EX.PC == target_pc ||
        EX_MEM.PC == target_pc ||
        MEM_WB.PC == target_pc) {
        
        cout << "\n>>> Knob5: Tracing instruction #" << knobs.Knob5 
             << " (PC=0x" << hex << target_pc << ") <<<\n";
        print_pipeline_registers();
    }
}
if (knobs.Knob6) {
  print_branch_predictor_state();
}

  
    
     

      cout << "Clock cycle " << dec << clock_cycles << " completed." << endl;
      cout << endl;
    }
  } else {
    // NON-PIPELINED MODE (sequential execution)
    while (1) {
      clock_cycles++;
      cout << "===== CLOCK CYCLE " << clock_cycles << " =====" << endl;
      fetch();
      if (IF_ID.instruction == 0xFFFFFFFF) {
        cout << "Simulation halted." << endl;
        break;
      }
      decode();
      execute();
      mem();
      write_back();
      if (knobs.Knob3) {
        string filename = "register_cycle_" + to_string(clock_cycles) + ".txt";
        write_register_file(filename);
    }
    if (knobs.Knob4) {
      print_pipeline_registers();
  }
  
    

      cout << "Clock cycle " << dec << clock_cycles << " completed." << endl;
      cout << endl;
    }
  }
}
void write_statistics(const string &filename = "simulation_stats.txt") {
  ofstream out(filename);
  if (!out) {
      cerr << "Error opening statistics file for writing: " << filename << endl;
      return;
  }

  stats.total_instructions = stats.alu_inst+stats.control_inst+stats.data_transfer_inst; // Subtract 1 for the halt instruction
  stats.total_cycles=4+stats.stalls+stats.total_instructions;
  if(stats.branch_mispredictions>0){stats.branch_mispredictions = stats.branch_mispredictions+1; }// No need to change this
  out << "===== SIMULATION STATISTICS =====\n";
  out << "Stat1: Total number of cycles: " << stats.total_cycles << "\n";
  out << "Stat2: Total instructions executed: " << stats.total_instructions << "\n";

  double cpi = stats.total_instructions ? 
               static_cast<double>(stats.total_cycles) / stats.total_instructions : 0.0;
  out << "Stat3: CPI: " << fixed << setprecision(2) << cpi << "\n";

  out << "Stat4: Data-transfer instructions: " << stats.data_transfer_inst << "\n";
  out << "Stat5: ALU instructions: " << stats.alu_inst << "\n";
  out << "Stat6: Control instructions: " << stats.control_inst << "\n";
  out << "Stat7: Stalls/bubbles in pipeline: " << stats.stalls << "\n";
  out << "Stat8: Data hazards: " << stats.data_hazards << "\n";
  out << "Stat9: Control hazards: " << stats.control_hazards << "\n";
  out << "Stat10: Branch mispredictions: " << stats.branch_mispredictions << "\n";
  out << "Stat11: Stalls due to data hazards: " << stats.data_stalls << "\n";
  out << "Stat12: Stalls due to control hazards: " << stats.control_stalls << "\n";

  out.close();
  cout << "Simulation statistics written to " << filename << endl;
}


int main() {
  reset_proc();                       // Initialize memory and registers
  load_program_memory("input.mc");    // Load program into memory
  load_data_memory("input_data.mem"); // Load data into data memory segment
  knobs.Knob1 = true; // Set to true for pipelined, false for sequential
  knobs.Knob2 = false;  // Disable data forwarding (will stall)
  knobs.Knob3 = false;   // Print register file after each cycle
  knobs.Knob4 = false;   // Print pipeline registers after each cycle
  knobs.Knob5 = -1;      // track the 10th instruction only
  knobs.Knob6 = true;   // Print memory after each cycle
  run_RISCVsim();                     // Start simulation
  write_data_memory(); // Write both memory segments to output file
  write_register_file();
  stats.total_cycles = clock_cycles;
write_statistics();  // Writes stats to file

  return 0;
}